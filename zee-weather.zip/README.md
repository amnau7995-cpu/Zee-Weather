# ZEE WEATHER

**Created By Zain**

ZEE WEATHER is a production-ready Android and web live weather application powered by **React**, **TypeScript**, **Vite**, **Tailwind CSS**, **Capacitor 8**, and the **Open-Meteo** live meteorological API.

---

## Application Configuration

- **App Name:** ZEE WEATHER
- **Android Package ID:** `com.zain.zeweather`
- **Version:** `1.0.0`
- **Weather Data Provider:** [Open-Meteo Forecast & Geocoding API](https://open-meteo.com/)

---

## Features

- **Animated Splash Screen:** Atmospheric emblem, **ZEE WEATHER** wordmark, and **Created By Zain** attribution with smooth fade-in and scale transitions into the dashboard.
- **Live Weather Dashboard:** Current temperature, weather condition, city & country, live city-timezone date and local time, feels-like temperature, humidity, wind speed & compass direction, visibility, UV index with risk scale, atmospheric pressure (hPa), and sunrise/sunset solar trajectory arc.
- **24-Hour & 7-Day Forecasts:** Scrollable next-24-hour outlook with precipitation probabilities and a 7-day forecast with scaled temperature range bars.
- **Automatic Device Location & City Search:** Uses Capacitor Geolocation on Android (with browser Geolocation fallback on web) plus live Open-Meteo city search and recent location switching.
- **Dynamic Animated Weather Backgrounds & Dual Theme:** Weather-reactive skies (clear sun, starry night, drifting clouds, rain streaks, thunderstorms, snow, and mist) with Light and Dark theme support and `°C` / `°F` unit switching.

---

## Project Setup & Web Development

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the local development server (port 3000):
   ```bash
   npm run dev
   ```

3. Build the production web bundle:
   ```bash
   npm run build
   ```

4. Run TypeScript type checks:
   ```bash
   npm run lint
   ```

---

## Building the Android APK (Capacitor + Android Studio / Gradle)

The native `/android` project is already generated and configured (`com.zain.zeweather`, version `1.0.0`, location & internet permissions in `android/app/src/main/AndroidManifest.xml`).

### Prerequisites
- **Node.js** 20+
- **Java Development Kit (JDK)** 21 (or 17)
- **Android Studio** (Ladybug or newer) with Android SDK Platform 36 (`compileSdkVersion = 36`, `minSdkVersion = 24`)

### Step-by-Step APK Build Instructions

1. **Build the web app and sync into Android:**
   ```bash
   npm install
   npm run build
   npx cap sync android
   ```
   *(If you ever regenerate the `/android` folder from scratch, run `npx cap add android` followed by `npx cap sync android`.)*

2. **Build a Debug APK via Gradle CLI:**
   ```bash
   cd android
   ./gradlew assembleDebug
   ```
   *(On Windows PowerShell/CMD: `gradlew.bat assembleDebug`)*

   The generated debug APK will be located at:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```

3. **Build a Signed Release APK via Android Studio:**
   ```bash
   npx cap open android
   ```
   In Android Studio:
   - Wait for Gradle sync to complete.
   - Select **Build > Generate Signed Bundle / APK...**
   - Choose **APK**, create or select your `.jks` keystore, select the `release` build variant, and click **Finish**.
   - The signed release APK will be output to `android/app/build/outputs/apk/release/app-release.apk`.

4. **Build a Release APK via Gradle CLI (optional with keystore):**
   ```bash
   cd android
   ./gradlew assembleRelease
   ```
