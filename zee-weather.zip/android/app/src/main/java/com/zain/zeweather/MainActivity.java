package com.zain.zeweather;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
