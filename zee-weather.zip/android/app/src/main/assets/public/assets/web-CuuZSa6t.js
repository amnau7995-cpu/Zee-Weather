import { t as WebPlugin } from "./index-CrkSX8Jj.js";
// node_modules/@capacitor/splash-screen/dist/esm/web.js
var SplashScreenWeb = class extends WebPlugin {
	async show(_options) {}
	async hide(_options) {}
};
export { SplashScreenWeb };
