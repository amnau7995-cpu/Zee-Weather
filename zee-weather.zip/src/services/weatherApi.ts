import { Capacitor } from '@capacitor/core';
import { Geolocation } from '@capacitor/geolocation';
import type { LocationItem, WeatherBundle } from '../types/weather';

const FORECAST_BASE = 'https://api.open-meteo.com/v1/forecast';
const GEOCODING_BASE = 'https://geocoding-api.open-meteo.com/v1/search';

interface OpenMeteoGeocodingResult {
  id: number;
  name: string;
  latitude: number;
  longitude: number;
  country?: string;
  country_code?: string;
  admin1?: string;
  timezone?: string;
}

interface OpenMeteoForecastResponse {
  latitude: number;
  longitude: number;
  utc_offset_seconds: number;
  timezone: string;
  timezone_abbreviation: string;
  current: {
    time: string;
    temperature_2m: number;
    relative_humidity_2m: number;
    apparent_temperature: number;
    is_day: number;
    precipitation: number;
    weather_code: number;
    cloud_cover: number;
    pressure_msl: number;
    surface_pressure: number;
    wind_speed_10m: number;
    wind_direction_10m: number;
  };
  hourly: {
    time: string[];
    temperature_2m: number[];
    apparent_temperature: number[];
    precipitation_probability: number[];
    weather_code: number[];
    visibility: number[];
    uv_index: number[];
    wind_speed_10m: number[];
    is_day: number[];
  };
  daily: {
    time: string[];
    weather_code: number[];
    temperature_2m_max: number[];
    temperature_2m_min: number[];
    sunrise: string[];
    sunset: string[];
    uv_index_max: number[];
    precipitation_probability_max: number[];
    wind_speed_10m_max: number[];
  };
}

export async function searchCities(query: string, signal?: AbortSignal): Promise<LocationItem[]> {
  const trimmed = query.trim();
  if (trimmed.length < 2) return [];

  const url = new URL(GEOCODING_BASE);
  url.searchParams.set('name', trimmed);
  url.searchParams.set('count', '8');
  url.searchParams.set('language', 'en');
  url.searchParams.set('format', 'json');

  const response = await fetch(url.toString(), { signal });
  if (!response.ok) {
    throw new Error(`City search failed (${response.status})`);
  }

  const data = (await response.json()) as { results?: OpenMeteoGeocodingResult[] };
  if (!data.results || data.results.length === 0) {
    return [];
  }

  return data.results.map((item) => ({
    id: `${item.id}-${item.latitude.toFixed(3)}-${item.longitude.toFixed(3)}`,
    name: item.name,
    country: item.country ?? item.country_code ?? '',
    admin1: item.admin1,
    latitude: item.latitude,
    longitude: item.longitude,
    timezone: item.timezone,
  }));
}

export async function reverseGeocodeCoords(
  latitude: number,
  longitude: number
): Promise<{ name: string; country: string; admin1?: string }> {
  // 1. Primary CORS-friendly reverse geocode
  try {
    const bdcUrl = `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=en`;
    const res = await fetch(bdcUrl);
    if (res.ok) {
      const data = (await res.json()) as {
        city?: string;
        locality?: string;
        principalSubdivision?: string;
        countryName?: string;
      };
      const name = data.city || data.locality || data.principalSubdivision;
      const country = data.countryName;
      if (name && country) {
        return {
          name,
          country,
          admin1: data.principalSubdivision !== name ? data.principalSubdivision : undefined,
        };
      }
    }
  } catch {
    // Fallback below
  }

  // 2. Fallback to OpenStreetMap Nominatim
  try {
    const nomUrl = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${latitude}&lon=${longitude}&accept-language=en`;
    const res = await fetch(nomUrl);
    if (res.ok) {
      const data = (await res.json()) as {
        address?: {
          city?: string;
          town?: string;
          village?: string;
          state?: string;
          country?: string;
        };
      };
      const addr = data.address;
      const name = addr?.city || addr?.town || addr?.village || addr?.state;
      if (name && addr?.country) {
        return { name, country: addr.country, admin1: addr.state };
      }
    }
  } catch {
    // Coordinate label fallback below
  }

  return {
    name: `${Math.abs(latitude).toFixed(2)}°${latitude >= 0 ? 'N' : 'S'}`,
    country: `${Math.abs(longitude).toFixed(2)}°${longitude >= 0 ? 'E' : 'W'}`,
  };
}

export async function getDeviceCoordinates(): Promise<{ latitude: number; longitude: number }> {
  if (Capacitor.isNativePlatform()) {
    const permStatus = await Geolocation.checkPermissions();
    if (permStatus.location !== 'granted' && permStatus.coarseLocation !== 'granted') {
      const requested = await Geolocation.requestPermissions();
      if (requested.location !== 'granted' && requested.coarseLocation !== 'granted') {
        throw new Error('Location permission was denied. Enable GPS access or search for a city.');
      }
    }

    const pos = await Geolocation.getCurrentPosition({
      enableHighAccuracy: false,
      timeout: 12000,
      maximumAge: 300000,
    });
    return {
      latitude: pos.coords.latitude,
      longitude: pos.coords.longitude,
    };
  }

  if (typeof navigator === 'undefined' || !('geolocation' in navigator)) {
    throw new Error('Geolocation is not supported in this browser.');
  }

  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        });
      },
      (err) => {
        if (err.code === err.PERMISSION_DENIED) {
          reject(new Error('Location permission denied. You can search any city above.'));
        } else if (err.code === err.TIMEOUT) {
          reject(new Error('Location request timed out. Please try again or search a city.'));
        } else {
          reject(new Error('Unable to detect device location. Search a city to view live weather.'));
        }
      },
      {
        enableHighAccuracy: false,
        timeout: 10000,
        maximumAge: 300000,
      }
    );
  });
}

export async function fetchWeatherForLocation(
  location: LocationItem,
  signal?: AbortSignal
): Promise<WeatherBundle> {
  const url = new URL(FORECAST_BASE);
  url.searchParams.set('latitude', String(location.latitude));
  url.searchParams.set('longitude', String(location.longitude));
  url.searchParams.set(
    'current',
    [
      'temperature_2m',
      'relative_humidity_2m',
      'apparent_temperature',
      'is_day',
      'precipitation',
      'weather_code',
      'cloud_cover',
      'pressure_msl',
      'surface_pressure',
      'wind_speed_10m',
      'wind_direction_10m',
    ].join(',')
  );
  url.searchParams.set(
    'hourly',
    [
      'temperature_2m',
      'apparent_temperature',
      'precipitation_probability',
      'weather_code',
      'visibility',
      'uv_index',
      'wind_speed_10m',
      'is_day',
    ].join(',')
  );
  url.searchParams.set(
    'daily',
    [
      'weather_code',
      'temperature_2m_max',
      'temperature_2m_min',
      'sunrise',
      'sunset',
      'uv_index_max',
      'precipitation_probability_max',
      'wind_speed_10m_max',
    ].join(',')
  );
  url.searchParams.set('timezone', 'auto');
  url.searchParams.set('forecast_days', '7');

  const response = await fetch(url.toString(), { signal });
  if (!response.ok) {
    throw new Error(`Open-Meteo API error (${response.status}). Please try again.`);
  }

  const data = (await response.json()) as OpenMeteoForecastResponse;

  // Find current hour index matching current observation hour prefix "YYYY-MM-DDTHH"
  const currentHourPrefix = data.current.time.slice(0, 13);
  let currentHourIdx = data.hourly.time.findIndex((t) => t.startsWith(currentHourPrefix));
  if (currentHourIdx === -1) {
    currentHourIdx = 0;
  }

  const next24Hours = data.hourly.time
    .slice(currentHourIdx, currentHourIdx + 24)
    .map((time, offset) => {
      const idx = currentHourIdx + offset;
      return {
        time,
        temperature: data.hourly.temperature_2m[idx] ?? data.current.temperature_2m,
        apparentTemperature:
          data.hourly.apparent_temperature[idx] ?? data.current.apparent_temperature,
        precipitationProbability: data.hourly.precipitation_probability[idx] ?? 0,
        weatherCode: data.hourly.weather_code[idx] ?? data.current.weather_code,
        visibility: data.hourly.visibility[idx] ?? 10000,
        uvIndex: data.hourly.uv_index[idx] ?? 0,
        windSpeed: data.hourly.wind_speed_10m[idx] ?? data.current.wind_speed_10m,
        isDay: (data.hourly.is_day[idx] ?? data.current.is_day) === 1,
      };
    });

  const daily = data.daily.time.map((date, idx) => ({
    date,
    weatherCode: data.daily.weather_code[idx] ?? 0,
    tempMax: data.daily.temperature_2m_max[idx] ?? 0,
    tempMin: data.daily.temperature_2m_min[idx] ?? 0,
    sunrise: data.daily.sunrise[idx] ?? `${date}T06:00`,
    sunset: data.daily.sunset[idx] ?? `${date}T18:00`,
    uvIndexMax: data.daily.uv_index_max[idx] ?? 0,
    precipitationProbabilityMax: data.daily.precipitation_probability_max[idx] ?? 0,
    windSpeedMax: data.daily.wind_speed_10m_max[idx] ?? 0,
  }));

  const currentVisibility = data.hourly.visibility[currentHourIdx] ?? 10000;
  const currentUv = data.hourly.uv_index[currentHourIdx] ?? 0;

  return {
    location: {
      ...location,
      timezone: data.timezone,
    },
    timezone: data.timezone,
    timezoneAbbreviation: data.timezone_abbreviation,
    utcOffsetSeconds: data.utc_offset_seconds,
    current: {
      temperature: data.current.temperature_2m,
      apparentTemperature: data.current.apparent_temperature,
      humidity: data.current.relative_humidity_2m,
      isDay: data.current.is_day === 1,
      precipitation: data.current.precipitation,
      weatherCode: data.current.weather_code,
      cloudCover: data.current.cloud_cover,
      pressureMsl: data.current.pressure_msl ?? data.current.surface_pressure,
      windSpeed: data.current.wind_speed_10m,
      windDirection: data.current.wind_direction_10m,
      visibility: currentVisibility,
      uvIndex: currentUv,
      observationTime: data.current.time,
    },
    hourly: next24Hours,
    daily,
    fetchedAt: Date.now(),
  };
}
