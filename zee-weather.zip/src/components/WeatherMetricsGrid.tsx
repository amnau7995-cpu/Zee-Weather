import {
  Droplets,
  Eye,
  Gauge,
  Sun,
  Sunrise,
  Sunset,
  Thermometer,
  Wind,
} from 'lucide-react';
import type { CurrentWeatherData, DailyForecastItem, TemperatureUnit } from '../types/weather';
import {
  formatIsoTimeExact,
  formatTemperature,
  formatVisibility,
  formatWindSpeed,
  getPressureLabel,
  getSolarProgress,
  getUvRating,
  getWindCompass,
} from '../utils/weatherCodes';

interface WeatherMetricsGridProps {
  current: CurrentWeatherData;
  today: DailyForecastItem | undefined;
  unit: TemperatureUnit;
}

export function WeatherMetricsGrid({ current, today, unit }: WeatherMetricsGridProps) {
  const feelsLike = formatTemperature(current.apparentTemperature, unit);
  const actualTemp = formatTemperature(current.temperature, unit);
  const uv = Math.round(current.uvIndex * 10) / 10;
  const uvInfo = getUvRating(uv);
  const pressure = Math.round(current.pressureMsl);
  const compass = getWindCompass(current.windDirection);

  const sunriseIso = today?.sunrise ?? `${current.observationTime.slice(0, 10)}T06:00`;
  const sunsetIso = today?.sunset ?? `${current.observationTime.slice(0, 10)}T18:00`;
  const solarProgress = getSolarProgress(sunriseIso, sunsetIso, current.observationTime);

  const feelsNote =
    feelsLike > actualTemp + 1
      ? 'Humidity makes it feel warmer'
      : feelsLike < actualTemp - 1
        ? 'Wind chill makes it feel cooler'
        : 'Similar to actual temperature';

  // Calculate sun dot on semi-circle arc (x: 10..150, y: 65..15)
  const angle = Math.PI * (1 - solarProgress);
  const sunX = 80 + 62 * Math.cos(angle);
  const sunY = 66 - 50 * Math.sin(angle);

  return (
    <section aria-label="Atmospheric conditions" className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
      {/* Feels Like */}
      <div className="rounded-3xl bg-white/75 dark:bg-slate-900/65 backdrop-blur-xl border border-slate-200/80 dark:border-white/10 p-4 sm:p-5 shadow-sm flex flex-col justify-between min-h-[136px]">
        <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
          <Thermometer className="h-4 w-4 text-orange-500 dark:text-orange-400 shrink-0" />
          <span>Feels Like</span>
        </div>
        <div>
          <p className="font-display text-2xl sm:text-3xl font-semibold text-slate-900 dark:text-white tabular-nums">
            {feelsLike}°{unit}
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 leading-snug">
            {feelsNote}
          </p>
        </div>
      </div>

      {/* Humidity */}
      <div className="rounded-3xl bg-white/75 dark:bg-slate-900/65 backdrop-blur-xl border border-slate-200/80 dark:border-white/10 p-4 sm:p-5 shadow-sm flex flex-col justify-between min-h-[136px]">
        <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
          <Droplets className="h-4 w-4 text-sky-500 dark:text-sky-400 shrink-0" />
          <span>Humidity</span>
        </div>
        <div>
          <p className="font-display text-2xl sm:text-3xl font-semibold text-slate-900 dark:text-white tabular-nums">
            {Math.round(current.humidity)}%
          </p>
          <div className="mt-2 h-1.5 w-full rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
            <div
              style={{ width: `${Math.min(100, Math.max(0, current.humidity))}%` }}
              className="h-full rounded-full bg-sky-500"
            />
          </div>
        </div>
      </div>

      {/* Wind Speed */}
      <div className="rounded-3xl bg-white/75 dark:bg-slate-900/65 backdrop-blur-xl border border-slate-200/80 dark:border-white/10 p-4 sm:p-5 shadow-sm flex flex-col justify-between min-h-[136px]">
        <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
          <Wind className="h-4 w-4 text-teal-500 dark:text-teal-400 shrink-0" />
          <span>Wind</span>
        </div>
        <div>
          <p className="font-display text-2xl sm:text-3xl font-semibold text-slate-900 dark:text-white tabular-nums">
            {formatWindSpeed(current.windSpeed, unit)}
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            Direction {compass} ({Math.round(current.windDirection)}°)
          </p>
        </div>
      </div>

      {/* Visibility */}
      <div className="rounded-3xl bg-white/75 dark:bg-slate-900/65 backdrop-blur-xl border border-slate-200/80 dark:border-white/10 p-4 sm:p-5 shadow-sm flex flex-col justify-between min-h-[136px]">
        <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
          <Eye className="h-4 w-4 text-indigo-500 dark:text-indigo-400 shrink-0" />
          <span>Visibility</span>
        </div>
        <div>
          <p className="font-display text-2xl sm:text-3xl font-semibold text-slate-900 dark:text-white tabular-nums">
            {formatVisibility(current.visibility, unit)}
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            {current.visibility >= 10000
              ? 'Clear horizon'
              : current.visibility >= 4000
                ? 'Moderate clarity'
                : 'Reduced visibility'}
          </p>
        </div>
      </div>

      {/* UV Index */}
      <div className="rounded-3xl bg-white/75 dark:bg-slate-900/65 backdrop-blur-xl border border-slate-200/80 dark:border-white/10 p-4 sm:p-5 shadow-sm flex flex-col justify-between min-h-[136px]">
        <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
          <Sun className="h-4 w-4 text-amber-500 dark:text-amber-400 shrink-0" />
          <span>UV Index</span>
        </div>
        <div>
          <div className="flex items-baseline gap-2">
            <p className="font-display text-2xl sm:text-3xl font-semibold text-slate-900 dark:text-white tabular-nums">
              {uv.toFixed(1)}
            </p>
            <span className="text-xs font-semibold text-amber-600 dark:text-amber-300">
              {uvInfo.label}
            </span>
          </div>
          <div className="mt-2 h-1.5 w-full rounded-full bg-gradient-to-r from-emerald-400 via-amber-400 to-rose-500 relative">
            <span
              style={{ left: `${Math.min(96, (uv / 11) * 100)}%` }}
              className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 h-2.5 w-2.5 rounded-full bg-white ring-2 ring-slate-900 dark:ring-white shadow"
            />
          </div>
        </div>
      </div>

      {/* Atmospheric Pressure */}
      <div className="rounded-3xl bg-white/75 dark:bg-slate-900/65 backdrop-blur-xl border border-slate-200/80 dark:border-white/10 p-4 sm:p-5 shadow-sm flex flex-col justify-between min-h-[136px]">
        <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
          <Gauge className="h-4 w-4 text-violet-500 dark:text-violet-400 shrink-0" />
          <span>Pressure</span>
        </div>
        <div>
          <p className="font-display text-2xl sm:text-3xl font-semibold text-slate-900 dark:text-white tabular-nums">
            {pressure} <span className="text-sm font-medium text-slate-500 dark:text-slate-400">hPa</span>
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            {getPressureLabel(pressure)}
          </p>
        </div>
      </div>

      {/* Sunrise & Sunset Solar Arc Card (Full Width of Grid) */}
      <div className="col-span-2 sm:col-span-3 rounded-3xl bg-white/75 dark:bg-slate-900/65 backdrop-blur-xl border border-slate-200/80 dark:border-white/10 p-5 shadow-sm">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <Sunrise className="h-5 w-5 text-amber-500 dark:text-amber-400 shrink-0" />
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Sunrise</p>
              <p className="font-display text-base sm:text-lg font-semibold text-slate-900 dark:text-white tabular-nums">
                {formatIsoTimeExact(sunriseIso)}
              </p>
            </div>
          </div>

          {/* Solar Trajectory Arc */}
          <svg
            viewBox="0 0 160 76"
            className="h-14 w-32 sm:w-44 shrink-0"
            aria-hidden="true"
          >
            <path
              d="M 18 66 A 62 50 0 0 1 142 66"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeDasharray="4 4"
              className="text-slate-300 dark:text-slate-700"
            />
            <line
              x1="10"
              y1="66"
              x2="150"
              y2="66"
              stroke="currentColor"
              strokeWidth="1.5"
              className="text-slate-200 dark:text-slate-800"
            />
            {current.isDay && (
              <>
                <circle cx={sunX} cy={sunY} r="7" className="fill-amber-400/30" />
                <circle cx={sunX} cy={sunY} r="4.2" className="fill-amber-400" />
              </>
            )}
          </svg>

          <div className="flex items-center gap-2.5 text-right">
            <div>
              <p className="text-xs text-slate-500 dark:text-slate-400">Sunset</p>
              <p className="font-display text-base sm:text-lg font-semibold text-slate-900 dark:text-white tabular-nums">
                {formatIsoTimeExact(sunsetIso)}
              </p>
            </div>
            <Sunset className="h-5 w-5 text-orange-500 dark:text-orange-400 shrink-0" />
          </div>
        </div>
      </div>
    </section>
  );
}
