import { Droplets } from 'lucide-react';
import type { DailyForecastItem, TemperatureUnit } from '../types/weather';
import {
  formatIsoDayName,
  formatIsoShortDate,
  formatTemperature,
  getWeatherInfo,
} from '../utils/weatherCodes';
import { WeatherIcon } from './WeatherIcon';

interface DailyForecastCardProps {
  daily: DailyForecastItem[];
  unit: TemperatureUnit;
}

export function DailyForecastCard({ daily, unit }: DailyForecastCardProps) {
  const weekMin = Math.min(...daily.map((d) => formatTemperature(d.tempMin, unit)));
  const weekMax = Math.max(...daily.map((d) => formatTemperature(d.tempMax, unit)));
  const totalSpan = Math.max(1, weekMax - weekMin);

  return (
    <section
      aria-label="7-day forecast"
      className="rounded-3xl bg-white/75 dark:bg-slate-900/65 backdrop-blur-xl border border-slate-200/80 dark:border-white/10 p-5 sm:p-6 shadow-sm"
    >
      <div className="flex items-baseline justify-between mb-3">
        <h2 className="font-display text-base sm:text-lg font-semibold text-slate-900 dark:text-white">
          7-Day Forecast
        </h2>
        <span className="text-xs text-slate-500 dark:text-slate-400">Daily range</span>
      </div>

      <div className="divide-y divide-slate-200/70 dark:divide-white/10">
        {daily.map((day, idx) => {
          const minTemp = formatTemperature(day.tempMin, unit);
          const maxTemp = formatTemperature(day.tempMax, unit);
          const info = getWeatherInfo(day.weatherCode);

          const leftPct = ((minTemp - weekMin) / totalSpan) * 100;
          const widthPct = Math.max(10, ((maxTemp - minTemp) / totalSpan) * 100);

          return (
            <div
              key={day.date}
              className="grid grid-cols-[84px_auto_1fr] sm:grid-cols-[100px_1fr_auto] items-center gap-3 py-3.5 first:pt-2 last:pb-1"
            >
              {/* Day + Date */}
              <div className="min-w-0">
                <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                  {formatIsoDayName(day.date, idx)}
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                  {formatIsoShortDate(day.date)}
                </p>
              </div>

              {/* Icon + Condition & Rain */}
              <div className="flex items-center gap-2.5 min-w-0">
                <WeatherIcon code={day.weatherCode} isDay size="sm" />
                <div className="min-w-0">
                  <p className="hidden sm:block text-sm text-slate-700 dark:text-slate-200 truncate">
                    {info.shortLabel}
                  </p>
                  {day.precipitationProbabilityMax > 0 && (
                    <span className="inline-flex items-center gap-0.5 text-xs font-medium text-sky-600 dark:text-sky-400 tabular-nums">
                      <Droplets className="h-3 w-3" />
                      {day.precipitationProbabilityMax}%
                    </span>
                  )}
                </div>
              </div>

              {/* Min Temp - Range Bar - Max Temp */}
              <div className="flex items-center justify-end gap-2.5 sm:gap-3">
                <span className="w-8 text-right text-sm font-medium text-slate-500 dark:text-slate-400 tabular-nums">
                  {minTemp}°
                </span>
                <div className="relative h-1.5 w-16 sm:w-28 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                  <div
                    style={{
                      left: `${leftPct}%`,
                      width: `${Math.min(100 - leftPct, widthPct)}%`,
                    }}
                    className="absolute inset-y-0 rounded-full bg-gradient-to-r from-sky-400 via-amber-400 to-orange-500"
                  />
                </div>
                <span className="w-8 text-right text-sm font-semibold text-slate-900 dark:text-white tabular-nums">
                  {maxTemp}°
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
