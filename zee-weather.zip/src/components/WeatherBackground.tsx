import type { ThemeMode, WeatherCategory } from '../types/weather';

interface WeatherBackgroundProps {
  category: WeatherCategory;
  isDay: boolean;
  theme: ThemeMode;
}

const RAIN_DROPS = [
  { left: '6%', delay: '0s', duration: '0.82s', height: '42px' },
  { left: '14%', delay: '0.3s', duration: '0.95s', height: '54px' },
  { left: '22%', delay: '0.6s', duration: '0.78s', height: '38px' },
  { left: '31%', delay: '0.15s', duration: '0.9s', height: '48px' },
  { left: '40%', delay: '0.52s', duration: '0.84s', height: '44px' },
  { left: '49%', delay: '0.24s', duration: '0.76s', height: '50px' },
  { left: '58%', delay: '0.7s', duration: '0.92s', height: '40px' },
  { left: '66%', delay: '0.12s', duration: '0.81s', height: '52px' },
  { left: '75%', delay: '0.45s', duration: '0.88s', height: '46px' },
  { left: '84%', delay: '0.22s', duration: '0.79s', height: '38px' },
  { left: '92%', delay: '0.64s', duration: '0.94s', height: '48px' },
  { left: '18%', delay: '0.42s', duration: '0.86s', height: '40px' },
  { left: '53%', delay: '0.08s', duration: '0.91s', height: '45px' },
  { left: '79%', delay: '0.58s', duration: '0.83s', height: '51px' },
];

const SNOW_FLAKES = [
  { left: '8%', delay: '0s', duration: '6.5s', size: 6 },
  { left: '19%', delay: '1.2s', duration: '7.4s', size: 8 },
  { left: '29%', delay: '2.6s', duration: '6.8s', size: 5 },
  { left: '41%', delay: '0.8s', duration: '8.1s', size: 7 },
  { left: '52%', delay: '3.1s', duration: '6.4s', size: 6 },
  { left: '63%', delay: '1.8s', duration: '7.6s', size: 8 },
  { left: '74%', delay: '0.4s', duration: '6.9s', size: 5 },
  { left: '85%', delay: '2.2s', duration: '7.8s', size: 7 },
  { left: '93%', delay: '1.5s', duration: '6.6s', size: 6 },
  { left: '34%', delay: '4.2s', duration: '7.2s', size: 6 },
  { left: '69%', delay: '3.7s', duration: '8.3s', size: 5 },
];

const STARS = [
  { top: '8%', left: '12%', size: 2, delay: '0.2s', duration: '3.4s' },
  { top: '14%', left: '28%', size: 3, delay: '1.1s', duration: '4.1s' },
  { top: '9%', left: '46%', size: 2, delay: '0.6s', duration: '3.8s' },
  { top: '19%', left: '63%', size: 2.5, delay: '1.9s', duration: '4.5s' },
  { top: '11%', left: '79%', size: 3, delay: '0.4s', duration: '3.2s' },
  { top: '24%', left: '88%', size: 2, delay: '1.5s', duration: '4.0s' },
  { top: '28%', left: '19%', size: 2, delay: '2.1s', duration: '3.7s' },
  { top: '22%', left: '41%', size: 2.5, delay: '0.9s', duration: '4.4s' },
  { top: '32%', left: '72%', size: 2, delay: '1.7s', duration: '3.6s' },
  { top: '6%', left: '91%', size: 2.5, delay: '0.3s', duration: '3.9s' },
];

function getSkyGradient(category: WeatherCategory, isDay: boolean, theme: ThemeMode): string {
  if (theme === 'dark') {
    if (!isDay) {
      switch (category) {
        case 'thunderstorm':
          return 'from-[#050814] via-[#0f172a] to-[#1e1b4b]';
        case 'rain':
        case 'drizzle':
          return 'from-[#060d1b] via-[#0f1d33] to-[#162742]';
        case 'snow':
          return 'from-[#091224] via-[#132542] to-[#1b3358]';
        default:
          return 'from-[#050b18] via-[#0b1830] to-[#13274a]';
      }
    }
    switch (category) {
      case 'clear':
        return 'from-[#07142b] via-[#0d274d] to-[#133b6e]';
      case 'partly-cloudy':
        return 'from-[#081529] via-[#11294a] to-[#1c3b63]';
      case 'cloudy':
      case 'fog':
        return 'from-[#0c1422] via-[#182438] to-[#23324a]';
      case 'rain':
      case 'drizzle':
        return 'from-[#091220] via-[#14253d] to-[#1b314d]';
      case 'thunderstorm':
        return 'from-[#070b18] via-[#141a30] to-[#1f2442]';
      case 'snow':
        return 'from-[#0d192b] via-[#1a2e4a] to-[#243f61]';
    }
  }

  // Light theme atmospheric gradients (high readability, serene sky palette)
  if (!isDay) {
    return 'from-[#e2e8f0] via-[#dbeafe] to-[#e0e7ff]';
  }

  switch (category) {
    case 'clear':
      return 'from-[#dbeafe] via-[#eff6ff] to-[#fef9c3]/40';
    case 'partly-cloudy':
      return 'from-[#dbeafe] via-[#e2e8f0] to-[#f1f5f9]';
    case 'cloudy':
    case 'fog':
      return 'from-[#cbd5e1] via-[#e2e8f0] to-[#f1f5f9]';
    case 'rain':
    case 'drizzle':
      return 'from-[#cbd5e1] via-[#dbeafe] to-[#e2e8f0]';
    case 'thunderstorm':
      return 'from-[#94a3b8]/60 via-[#cbd5e1] to-[#e2e8f0]';
    case 'snow':
      return 'from-[#e0f2fe] via-[#f0f9ff] to-[#f8fafc]';
  }
}

export function WeatherBackground({ category, isDay, theme }: WeatherBackgroundProps) {
  const skyClass = getSkyGradient(category, isDay, theme);
  const showSun = isDay && (category === 'clear' || category === 'partly-cloudy');
  const showStars = !isDay && (category === 'clear' || category === 'partly-cloudy') && theme === 'dark';
  const showClouds =
    category === 'partly-cloudy' ||
    category === 'cloudy' ||
    category === 'rain' ||
    category === 'drizzle' ||
    category === 'thunderstorm';
  const showRain = category === 'rain' || category === 'drizzle' || category === 'thunderstorm';
  const showSnow = category === 'snow';
  const showFog = category === 'fog';
  const showLightning = category === 'thunderstorm';

  return (
    <div
      aria-hidden="true"
      className={`pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-gradient-to-b ${skyClass} transition-colors duration-700`}
    >
      {/* Daytime Radiant Sunshine Aura */}
      {showSun && (
        <div className="absolute -top-28 right-[-8%] sm:right-[6%] h-[420px] w-[420px]">
          <div
            className={`h-full w-full rounded-full blur-3xl animate-solar-breathe ${
              theme === 'dark' ? 'bg-amber-400/20' : 'bg-amber-300/45'
            }`}
          />
          <div
            className={`absolute inset-16 rounded-full border border-dashed animate-solar-spin ${
              theme === 'dark' ? 'border-amber-200/10' : 'border-amber-500/15'
            }`}
          />
        </div>
      )}

      {/* Nighttime Stars */}
      {showStars &&
        STARS.map((star, idx) => (
          <span
            key={idx}
            style={{
              top: star.top,
              left: star.left,
              width: `${star.size}px`,
              height: `${star.size}px`,
              animationDelay: star.delay,
              animationDuration: star.duration,
            }}
            className="absolute rounded-full bg-white animate-star-twinkle"
          />
        ))}

      {/* Drifting Layered Clouds */}
      {showClouds && (
        <>
          <svg
            viewBox="0 0 420 150"
            className={`absolute top-[4%] -left-16 w-[340px] sm:w-[460px] animate-cloud-slow ${
              theme === 'dark' ? 'opacity-[0.07]' : 'opacity-50'
            }`}
            fill="none"
          >
            <path
              d="M74 128h260c28 0 50-22 50-49 0-24-18-45-41-48-11-26-38-43-68-43-34 0-63 22-72 53-6-2-13-3-20-3-32 0-58 25-58 57 0 18-23 33-51 33Z"
              fill="white"
            />
          </svg>
          <svg
            viewBox="0 0 420 150"
            className={`absolute top-[18%] -right-12 w-[300px] sm:w-[400px] animate-cloud-fast ${
              theme === 'dark' ? 'opacity-[0.05]' : 'opacity-40'
            }`}
            fill="none"
          >
            <path
              d="M74 128h260c28 0 50-22 50-49 0-24-18-45-41-48-11-26-38-43-68-43-34 0-63 22-72 53-6-2-13-3-20-3-32 0-58 25-58 57 0 18-23 33-51 33Z"
              fill="white"
            />
          </svg>
        </>
      )}

      {/* Fog / Mist Layers */}
      {showFog && (
        <>
          <div
            className={`absolute top-[18%] -left-10 right-[-10%] h-36 rounded-full blur-3xl animate-mist ${
              theme === 'dark' ? 'bg-slate-400/12' : 'bg-white/65'
            }`}
          />
          <div
            className={`absolute top-[48%] -left-10 right-[-10%] h-44 rounded-full blur-3xl animate-mist ${
              theme === 'dark' ? 'bg-slate-300/10' : 'bg-white/55'
            }`}
          />
        </>
      )}

      {/* Animated Rain Streaks */}
      {showRain &&
        RAIN_DROPS.map((drop, idx) => (
          <span
            key={idx}
            style={{
              left: drop.left,
              height: drop.height,
              animationDelay: drop.delay,
              animationDuration: drop.duration,
            }}
            className={`absolute top-0 w-[1.5px] rounded-full animate-rain-fall ${
              theme === 'dark'
                ? 'bg-gradient-to-b from-transparent via-sky-300/55 to-sky-100/80'
                : 'bg-gradient-to-b from-transparent via-sky-600/35 to-sky-700/55'
            }`}
          />
        ))}

      {/* Animated Snowflakes */}
      {showSnow &&
        SNOW_FLAKES.map((flake, idx) => (
          <span
            key={idx}
            style={{
              left: flake.left,
              width: `${flake.size}px`,
              height: `${flake.size}px`,
              animationDelay: flake.delay,
              animationDuration: flake.duration,
            }}
            className={`absolute top-0 rounded-full animate-snow-fall ${
              theme === 'dark' ? 'bg-white/75' : 'bg-sky-500/45'
            }`}
          />
        ))}

      {/* Thunderstorm Atmospheric Flash */}
      {showLightning && (
        <div className="absolute inset-0 bg-indigo-200 animate-lightning" />
      )}
    </div>
  );
}
