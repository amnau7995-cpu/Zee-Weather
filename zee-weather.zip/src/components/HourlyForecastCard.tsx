import { Droplets } from 'lucide-react';
import type { HourlyForecastItem, TemperatureUnit } from '../types/weather';
import { formatIsoHour, formatTemperature, getWeatherInfo } from '../utils/weatherCodes';
import { WeatherIcon } from './WeatherIcon';

interface HourlyForecastCardProps {
  hourly: HourlyForecastItem[];
  unit: TemperatureUnit;
}

export function HourlyForecastCard({ hourly, unit }: HourlyForecastCardProps) {
  return (
    <section
      aria-label="24-hour forecast"
      className="rounded-3xl bg-white/75 dark:bg-slate-900/65 backdrop-blur-xl border border-slate-200/80 dark:border-white/10 p-5 sm:p-6 shadow-sm"
    >
      <div className="flex items-baseline justify-between mb-4">
        <h2 className="font-display text-base sm:text-lg font-semibold text-slate-900 dark:text-white">
          Hourly Forecast
        </h2>
        <span className="text-xs text-slate-500 dark:text-slate-400">Next 24 hours</span>
      </div>

      <div className="hourly-scroll flex items-stretch gap-2.5 overflow-x-auto pb-2">
        {hourly.map((slot, index) => {
          const isNow = index === 0;
          const temp = formatTemperature(slot.temperature, unit);
          const info = getWeatherInfo(slot.weatherCode);

          return (
            <div
              key={slot.time}
              className={`flex flex-col items-center justify-between shrink-0 w-[72px] rounded-2xl py-3 px-2 transition-colors ${
                isNow
                  ? 'bg-sky-600 text-white dark:bg-sky-500/25 dark:text-white dark:ring-1 dark:ring-sky-400/40'
                  : 'bg-slate-100/80 dark:bg-white/[0.04] text-slate-800 dark:text-slate-100'
              }`}
            >
              <span
                className={`text-xs font-medium tabular-nums ${
                  isNow ? 'text-white/95' : 'text-slate-500 dark:text-slate-400'
                }`}
              >
                {isNow ? 'Now' : formatIsoHour(slot.time)}
              </span>

              <div className="my-2.5 flex flex-col items-center">
                <WeatherIcon
                  code={slot.weatherCode}
                  isDay={slot.isDay}
                  size="md"
                  className={isNow ? '!text-white' : ''}
                />
                <span
                  className={`mt-1.5 flex items-center gap-0.5 text-[11px] font-medium tabular-nums min-h-[16px] ${
                    slot.precipitationProbability > 0
                      ? isNow
                        ? 'text-sky-100'
                        : 'text-sky-600 dark:text-sky-400'
                      : 'opacity-0'
                  }`}
                  aria-label={
                    slot.precipitationProbability > 0
                      ? `${slot.precipitationProbability}% precipitation chance`
                      : undefined
                  }
                >
                  <Droplets className="h-3 w-3" />
                  {slot.precipitationProbability}%
                </span>
              </div>

              <span
                title={info.label}
                className="font-display text-base font-semibold tabular-nums"
              >
                {temp}°
              </span>
            </div>
          );
        })}
      </div>
    </section>
  );
}
