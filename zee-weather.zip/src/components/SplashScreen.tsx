import { useEffect, useState } from 'react';

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    const fadeTimer = window.setTimeout(() => {
      setExiting(true);
    }, 1850);

    const doneTimer = window.setTimeout(() => {
      onComplete();
    }, 2400);

    return () => {
      window.clearTimeout(fadeTimer);
      window.clearTimeout(doneTimer);
    };
  }, [onComplete]);

  return (
    <div
      role="status"
      aria-label="Loading ZEE WEATHER"
      onClick={() => {
        setExiting(true);
        window.setTimeout(onComplete, 350);
      }}
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center overflow-hidden bg-gradient-to-br from-[#071124] via-[#0e2042] to-[#153566] text-white transition-all duration-500 ease-out cursor-pointer select-none ${
        exiting ? 'opacity-0 scale-[1.03] pointer-events-none' : 'opacity-100 scale-100'
      }`}
    >
      {/* Atmospheric background sun orb & drifting cloud layer */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-24 right-[-10%] h-[360px] w-[360px] rounded-full bg-amber-300/20 blur-3xl animate-solar-breathe"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-28 left-[-10%] h-[340px] w-[340px] rounded-full bg-sky-400/20 blur-3xl animate-cloud-slow"
      />

      {/* Subtle geometric cloud silhouettes */}
      <svg
        aria-hidden="true"
        viewBox="0 0 400 160"
        className="pointer-events-none absolute top-[18%] left-[5%] w-72 opacity-15 animate-cloud-slow"
        fill="none"
      >
        <path
          d="M74 128h238c28 0 50-22 50-49 0-24-18-45-41-48-11-26-38-43-68-43-34 0-63 22-72 53-6-2-13-3-20-3-32 0-58 25-58 57 0 18-13 33-29 33Z"
          fill="white"
        />
      </svg>

      {/* Center Brand Emblem */}
      <div className="relative flex flex-col items-center px-6 text-center">
        <div className="animate-splash-logo relative mb-7 flex h-24 w-24 items-center justify-center rounded-3xl bg-white/10 shadow-2xl ring-1 ring-white/20 backdrop-blur-md">
          <div className="absolute -inset-3 rounded-full bg-amber-400/20 blur-xl animate-solar-breathe" />
          <svg viewBox="0 0 64 64" className="relative h-14 w-14" fill="none">
            <defs>
              <linearGradient id="splashSun" x1="16" y1="12" x2="40" y2="36" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#fde047" />
                <stop offset="100%" stopColor="#f97316" />
              </linearGradient>
            </defs>
            <circle cx="27" cy="24" r="11" fill="url(#splashSun)" />
            <path
              d="M21 46h24a8.5 8.5 0 0 0 1.4-16.88A11.5 11.5 0 0 0 24.1 27.5 9.5 9.5 0 0 0 21 46Z"
              fill="#f8fafc"
            />
          </svg>
        </div>

        <h1 className="animate-splash-logo font-display text-4xl sm:text-5xl font-bold tracking-tight text-white">
          ZEE WEATHER
        </h1>

        <p className="animate-splash-sub mt-3 text-sm sm:text-base font-medium tracking-[0.2em] text-sky-200/90">
          Created By Zain
        </p>
      </div>

      {/* Subtle bottom loading bar */}
      <div className="animate-splash-sub absolute bottom-12 flex flex-col items-center gap-3 pb-safe">
        <div className="h-1 w-32 overflow-hidden rounded-full bg-white/15">
          <div className="h-full w-full origin-left animate-[splashLogoIn_1.8s_ease-out_forwards] rounded-full bg-gradient-to-r from-sky-300 via-amber-200 to-sky-300" />
        </div>
      </div>
    </div>
  );
}
