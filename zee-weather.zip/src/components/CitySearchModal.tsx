import { useEffect, useRef, useState } from 'react';
import { Loader2, MapPin, Navigation, Search, X } from 'lucide-react';
import { searchCities } from '../services/weatherApi';
import type { LocationItem } from '../types/weather';

interface CitySearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectLocation: (location: LocationItem) => void;
  onUseCurrentLocation: () => void;
  locatingGps: boolean;
  recentLocations: LocationItem[];
}

export function CitySearchModal({
  isOpen,
  onClose,
  onSelectLocation,
  onUseCurrentLocation,
  locatingGps,
  recentLocations,
}: CitySearchModalProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<LocationItem[]>([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      const timer = window.setTimeout(() => {
        inputRef.current?.focus();
      }, 80);
      return () => window.clearTimeout(timer);
    } else {
      setQuery('');
      setResults([]);
      setSearchError(null);
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const trimmed = query.trim();
    if (trimmed.length < 2) {
      setResults([]);
      setSearchError(null);
      setSearching(false);
      return;
    }

    const controller = new AbortController();
    const debounce = window.setTimeout(async () => {
      setSearching(true);
      setSearchError(null);
      try {
        const cities = await searchCities(trimmed, controller.signal);
        setResults(cities);
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          setSearchError((err as Error).message || 'Unable to search cities.');
        }
      } finally {
        setSearching(false);
      }
    }, 280);

    return () => {
      controller.abort();
      window.clearTimeout(debounce);
    };
  }, [query, isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-40 flex items-start justify-center bg-slate-950/50 backdrop-blur-sm p-3 sm:p-6 pt-safe"
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Search city weather"
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-xl mt-2 sm:mt-10 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xl overflow-hidden transition-all"
      >
        {/* Search Input Header */}
        <div className="flex items-center gap-2 px-4 py-3 border-b border-slate-200/80 dark:border-slate-800">
          <Search className="h-5 w-5 text-slate-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search city or region (e.g. Lahore, Tokyo, London)"
            aria-label="City name"
            className="w-full min-h-[44px] bg-transparent text-base text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery('')}
              aria-label="Clear search"
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] px-3 text-sm font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white rounded-xl transition-colors whitespace-nowrap shrink-0"
          >
            Cancel
          </button>
        </div>

        {/* GPS Location Action */}
        <div className="px-4 py-3 border-b border-slate-100 dark:border-slate-800/80">
          <button
            type="button"
            disabled={locatingGps}
            onClick={() => {
              onUseCurrentLocation();
              onClose();
            }}
            className="w-full min-h-[48px] flex items-center justify-between px-4 rounded-2xl bg-sky-50 dark:bg-sky-500/10 text-sky-700 dark:text-sky-300 hover:bg-sky-100 dark:hover:bg-sky-500/20 transition-colors font-medium text-sm"
          >
            <span className="flex items-center gap-3">
              <Navigation className="h-4 w-4 shrink-0" />
              <span>Use Current Device Location</span>
            </span>
            {locatingGps && <Loader2 className="h-4 w-4 animate-spin shrink-0" />}
          </button>
        </div>

        {/* Results or Recent Searches */}
        <div className="max-h-[58vh] overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/70">
          {searching && (
            <div className="flex items-center justify-center gap-2 py-8 text-sm text-slate-500 dark:text-slate-400">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Searching Open-Meteo directory...</span>
            </div>
          )}

          {!searching && searchError && (
            <div className="px-5 py-6 text-sm text-rose-600 dark:text-rose-400">
              {searchError}
            </div>
          )}

          {!searching && !searchError && query.trim().length >= 2 && results.length === 0 && (
            <div className="px-5 py-8 text-center text-sm text-slate-500 dark:text-slate-400">
              No matching cities found for &ldquo;{query.trim()}&rdquo;.
            </div>
          )}

          {!searching &&
            results.map((city) => (
              <button
                key={city.id}
                type="button"
                onClick={() => {
                  onSelectLocation(city);
                  onClose();
                }}
                className="w-full min-h-[56px] flex items-center justify-between gap-3 px-5 py-3 text-left hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <MapPin className="h-4 w-4 text-slate-400 shrink-0" />
                  <div className="min-w-0">
                    <p className="font-medium text-slate-900 dark:text-slate-100 truncate">
                      {city.name}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                      {[city.admin1, city.country].filter(Boolean).join(', ')}
                    </p>
                  </div>
                </div>
                <span className="font-mono text-xs text-slate-400 tabular-nums shrink-0">
                  {city.latitude.toFixed(2)}°, {city.longitude.toFixed(2)}°
                </span>
              </button>
            ))}

          {query.trim().length < 2 && recentLocations.length > 0 && (
            <div>
              <p className="px-5 pt-3.5 pb-1.5 text-xs font-medium text-slate-400 dark:text-slate-500">
                Recent Locations
              </p>
              {recentLocations.map((city) => (
                <button
                  key={city.id}
                  type="button"
                  onClick={() => {
                    onSelectLocation(city);
                    onClose();
                  }}
                  className="w-full min-h-[54px] flex items-center justify-between gap-3 px-5 py-3 text-left hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <MapPin className="h-4 w-4 text-sky-500 shrink-0" />
                    <div className="min-w-0">
                      <p className="font-medium text-slate-900 dark:text-slate-100 truncate">
                        {city.name}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {[city.admin1, city.country].filter(Boolean).join(', ')}
                      </p>
                    </div>
                  </div>
                  <span className="text-xs text-slate-400 shrink-0">Select</span>
                </button>
              ))}
            </div>
          )}

          {query.trim().length < 2 && recentLocations.length === 0 && (
            <div className="px-5 py-8 text-center text-sm text-slate-500 dark:text-slate-400">
              Type at least 2 characters to search any city worldwide.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
