import {
  Cloud,
  CloudDrizzle,
  CloudFog,
  CloudLightning,
  CloudRain,
  CloudSnow,
  CloudSun,
  CloudMoon,
  Moon,
  Sun,
} from 'lucide-react';
import { getWeatherInfo } from '../utils/weatherCodes';

interface WeatherIconProps {
  code: number;
  isDay?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'hero';
  className?: string;
}

export function WeatherIcon({
  code,
  isDay = true,
  size = 'md',
  className = '',
}: WeatherIconProps) {
  const { category } = getWeatherInfo(code);

  if (size === 'hero') {
    return (
      <div className={`relative flex items-center justify-center ${className}`} aria-hidden="true">
        {category === 'clear' && isDay && (
          <div className="relative flex h-24 w-24 items-center justify-center">
            <div className="absolute inset-1 rounded-full bg-amber-400/30 blur-xl animate-solar-breathe" />
            <div className="h-16 w-16 rounded-full bg-gradient-to-br from-amber-200 via-amber-400 to-orange-500 shadow-lg shadow-amber-500/30" />
          </div>
        )}

        {category === 'clear' && !isDay && (
          <div className="relative flex h-24 w-24 items-center justify-center">
            <div className="absolute inset-2 rounded-full bg-indigo-400/25 blur-xl animate-solar-breathe" />
            <Moon className="h-16 w-16 text-indigo-100 fill-indigo-200/80 drop-shadow-md" strokeWidth={1.5} />
          </div>
        )}

        {category === 'partly-cloudy' && (
          <div className="relative flex h-24 w-24 items-center justify-center">
            {isDay ? (
              <div className="absolute top-2 right-3 h-11 w-11 rounded-full bg-gradient-to-br from-amber-200 to-orange-400 shadow-md animate-solar-breathe" />
            ) : (
              <Moon className="absolute top-2 right-3 h-10 w-10 text-indigo-200 fill-indigo-200/70" strokeWidth={1.5} />
            )}
            <Cloud
              className="relative mt-4 mr-2 h-16 w-16 text-white fill-white/90 drop-shadow-lg dark:text-slate-100"
              strokeWidth={1.4}
            />
          </div>
        )}

        {category === 'cloudy' && (
          <div className="relative flex h-24 w-24 items-center justify-center">
            <Cloud className="h-16 w-16 text-slate-100 fill-slate-200/90 drop-shadow-lg" strokeWidth={1.5} />
          </div>
        )}

        {category === 'fog' && (
          <div className="relative flex h-24 w-24 items-center justify-center">
            <CloudFog className="h-16 w-16 text-slate-200 drop-shadow-md" strokeWidth={1.6} />
          </div>
        )}

        {category === 'drizzle' && (
          <div className="relative flex h-24 w-24 items-center justify-center">
            <CloudDrizzle className="h-16 w-16 text-sky-100 drop-shadow-md" strokeWidth={1.6} />
          </div>
        )}

        {category === 'rain' && (
          <div className="relative flex h-24 w-24 items-center justify-center">
            <CloudRain className="h-16 w-16 text-sky-100 drop-shadow-md" strokeWidth={1.6} />
          </div>
        )}

        {category === 'snow' && (
          <div className="relative flex h-24 w-24 items-center justify-center">
            <CloudSnow className="h-16 w-16 text-cyan-50 drop-shadow-md" strokeWidth={1.6} />
          </div>
        )}

        {category === 'thunderstorm' && (
          <div className="relative flex h-24 w-24 items-center justify-center">
            <CloudLightning className="h-16 w-16 text-amber-200 drop-shadow-md" strokeWidth={1.6} />
          </div>
        )}
      </div>
    );
  }

  const sizeClass =
    size === 'sm' ? 'h-5 w-5' : size === 'lg' ? 'h-8 w-8' : 'h-6 w-6';

  switch (category) {
    case 'clear':
      return isDay ? (
        <Sun className={`${sizeClass} text-amber-400 shrink-0 ${className}`} strokeWidth={2} />
      ) : (
        <Moon className={`${sizeClass} text-indigo-300 shrink-0 ${className}`} strokeWidth={2} />
      );
    case 'partly-cloudy':
      return isDay ? (
        <CloudSun className={`${sizeClass} text-amber-300 shrink-0 ${className}`} strokeWidth={2} />
      ) : (
        <CloudMoon className={`${sizeClass} text-slate-300 shrink-0 ${className}`} strokeWidth={2} />
      );
    case 'cloudy':
      return <Cloud className={`${sizeClass} text-slate-400 dark:text-slate-300 shrink-0 ${className}`} strokeWidth={2} />;
    case 'fog':
      return <CloudFog className={`${sizeClass} text-slate-400 dark:text-slate-300 shrink-0 ${className}`} strokeWidth={2} />;
    case 'drizzle':
      return <CloudDrizzle className={`${sizeClass} text-sky-400 shrink-0 ${className}`} strokeWidth={2} />;
    case 'rain':
      return <CloudRain className={`${sizeClass} text-sky-500 dark:text-sky-400 shrink-0 ${className}`} strokeWidth={2} />;
    case 'snow':
      return <CloudSnow className={`${sizeClass} text-cyan-400 dark:text-cyan-200 shrink-0 ${className}`} strokeWidth={2} />;
    case 'thunderstorm':
      return <CloudLightning className={`${sizeClass} text-amber-400 shrink-0 ${className}`} strokeWidth={2} />;
  }
}
