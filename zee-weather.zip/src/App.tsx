import { useCallback, useEffect, useMemo, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { SplashScreen as NativeSplashScreen } from '@capacitor/splash-screen';
import { StatusBar, Style } from '@capacitor/status-bar';
import {
  AlertCircle,
  Loader2,
  MapPin,
  Moon,
  Navigation,
  RefreshCw,
  Search,
  Sun,
} from 'lucide-react';
import { CitySearchModal } from './components/CitySearchModal';
import { DailyForecastCard } from './components/DailyForecastCard';
import { HourlyForecastCard } from './components/HourlyForecastCard';
import { SplashScreen } from './components/SplashScreen';
import { WeatherBackground } from './components/WeatherBackground';
import { WeatherIcon } from './components/WeatherIcon';
import { WeatherMetricsGrid } from './components/WeatherMetricsGrid';
import {
  fetchWeatherForLocation,
  getDeviceCoordinates,
  reverseGeocodeCoords,
} from './services/weatherApi';
import type {
  LocationItem,
  TemperatureUnit,
  ThemeMode,
  WeatherBundle,
} from './types/weather';
import {
  formatCityDateTime,
  formatTemperature,
  getWeatherInfo,
} from './utils/weatherCodes';

const STORAGE_KEYS = {
  theme: 'zee_weather_theme',
  unit: 'zee_weather_unit',
  location: 'zee_weather_last_location',
  recents: 'zee_weather_recent_locations',
};

const FALLBACK_CITY: LocationItem = {
  id: 'default-london',
  name: 'London',
  country: 'United Kingdom',
  admin1: 'England',
  latitude: 51.5074,
  longitude: -0.1278,
  timezone: 'Europe/London',
};

function readStoredTheme(): ThemeMode {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.theme);
    if (saved === 'light' || saved === 'dark') return saved;
  } catch {
    // ignore storage errors
  }
  return 'dark';
}

function readStoredUnit(): TemperatureUnit {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.unit);
    if (saved === 'C' || saved === 'F') return saved;
  } catch {
    // ignore
  }
  return 'C';
}

function readStoredRecents(): LocationItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.recents);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.slice(0, 6) : [];
  } catch {
    return [];
  }
}

function readStoredLocation(): LocationItem | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.location);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as LocationItem;
    if (typeof parsed?.latitude === 'number' && typeof parsed?.longitude === 'number') {
      return parsed;
    }
  } catch {
    // ignore
  }
  return null;
}

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [theme, setTheme] = useState<ThemeMode>(readStoredTheme);
  const [unit, setUnit] = useState<TemperatureUnit>(readStoredUnit);
  const [weather, setWeather] = useState<WeatherBundle | null>(null);
  const [activeLocation, setActiveLocation] = useState<LocationItem | null>(readStoredLocation);
  const [recentLocations, setRecentLocations] = useState<LocationItem[]>(readStoredRecents);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [locatingGps, setLocatingGps] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [locationNotice, setLocationNotice] = useState<string | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [now, setNow] = useState(() => new Date());

  // Sync theme class on <html> & Capacitor StatusBar
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      localStorage.setItem(STORAGE_KEYS.theme, theme);
    } catch {
      // ignore
    }

    if (Capacitor.isNativePlatform()) {
      StatusBar.setStyle({
        style: theme === 'dark' ? Style.Dark : Style.Light,
      }).catch(() => undefined);
    }
  }, [theme]);

  // Persist unit
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.unit, unit);
    } catch {
      // ignore
    }
  }, [unit]);

  // Hide native Android splash screen once webview mounts
  useEffect(() => {
    if (Capacitor.isNativePlatform()) {
      NativeSplashScreen.hide().catch(() => undefined);
    }
  }, []);

  // Keep city local time ticking
  useEffect(() => {
    const interval = window.setInterval(() => {
      setNow(new Date());
    }, 30000);
    return () => window.clearInterval(interval);
  }, []);

  const pushRecentLocation = useCallback((loc: LocationItem) => {
    setRecentLocations((prev) => {
      const filtered = prev.filter(
        (item) =>
          !(
            Math.abs(item.latitude - loc.latitude) < 0.02 &&
            Math.abs(item.longitude - loc.longitude) < 0.02
          )
      );
      const next = [loc, ...filtered].slice(0, 6);
      try {
        localStorage.setItem(STORAGE_KEYS.recents, JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
  }, []);

  const loadWeather = useCallback(
    async (location: LocationItem, options?: { isRefresh?: boolean; notice?: string | null }) => {
      const isRefresh = options?.isRefresh ?? false;
      if (isRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }
      setErrorMsg(null);
      if (options?.notice !== undefined) {
        setLocationNotice(options.notice);
      }

      try {
        const bundle = await fetchWeatherForLocation(location);
        setWeather(bundle);
        setActiveLocation(bundle.location);
        setNow(new Date());
        try {
          localStorage.setItem(STORAGE_KEYS.location, JSON.stringify(bundle.location));
        } catch {
          // ignore
        }
        if (!location.isCurrentLocation) {
          pushRecentLocation(bundle.location);
        }
      } catch (err) {
        setErrorMsg(
          (err as Error).message ||
            'Unable to reach Open-Meteo weather service. Check your internet connection and retry.'
        );
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [pushRecentLocation]
  );

  const detectAndLoadCurrentLocation = useCallback(
    async (isInitialBoot = false) => {
      setLocatingGps(true);
      setErrorMsg(null);
      setLocationNotice(null);

      try {
        const coords = await getDeviceCoordinates();
        const place = await reverseGeocodeCoords(coords.latitude, coords.longitude);
        const gpsLocation: LocationItem = {
          id: `gps-${coords.latitude.toFixed(3)}-${coords.longitude.toFixed(3)}`,
          name: place.name,
          country: place.country,
          admin1: place.admin1,
          latitude: coords.latitude,
          longitude: coords.longitude,
          isCurrentLocation: true,
        };
        await loadWeather(gpsLocation, { notice: null });
      } catch (err) {
        const message = (err as Error).message || 'Location permission unavailable.';
        if (isInitialBoot) {
          const fallback = readStoredLocation() ?? FALLBACK_CITY;
          await loadWeather(fallback, {
            notice: `${message} Showing live weather for ${fallback.name}.`,
          });
        } else {
          setLocationNotice(message);
        }
      } finally {
        setLocatingGps(false);
      }
    },
    [loadWeather]
  );

  // Initial load: attempt real device location with permission
  useEffect(() => {
    void detectAndLoadCurrentLocation(true);
  }, [detectAndLoadCurrentLocation]);

  const handleRefresh = () => {
    if (activeLocation) {
      void loadWeather(activeLocation, { isRefresh: true });
    } else {
      void detectAndLoadCurrentLocation(false);
    }
  };

  const handleSelectCity = (city: LocationItem) => {
    setLocationNotice(null);
    void loadWeather(city, { notice: null });
  };

  const currentInfo = useMemo(
    () => (weather ? getWeatherInfo(weather.current.weatherCode) : getWeatherInfo(0)),
    [weather]
  );

  const cityClock = useMemo(() => {
    if (!weather) return { dateText: '', timeText: '' };
    return formatCityDateTime(weather.timezone, now);
  }, [weather, now]);

  const todayForecast = weather?.daily[0];
  const lastUpdatedLabel = useMemo(() => {
    if (!weather) return '';
    return new Date(weather.fetchedAt).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
    });
  }, [weather]);

  return (
    <div className="relative min-h-dvh text-slate-900 dark:text-slate-100 selection:bg-sky-500/30">
      {showSplash && <SplashScreen onComplete={() => setShowSplash(false)} />}

      <WeatherBackground
        category={currentInfo.category}
        isDay={weather?.current.isDay ?? true}
        theme={theme}
      />

      {/* Sticky Compact Mobile & Desktop Top Bar */}
      <header className="sticky top-0 z-30 pt-safe bg-white/65 dark:bg-slate-950/60 backdrop-blur-xl border-b border-slate-200/70 dark:border-white/10">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 h-14 sm:h-16 flex items-center justify-between gap-3">
          {/* Brand Wordmark */}
          <button
            type="button"
            onClick={handleRefresh}
            className="flex items-center gap-2.5 text-left min-h-[44px] whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 rounded-xl px-1"
          >
            <span className="font-display text-lg sm:text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              ZEE WEATHER
            </span>
          </button>

          {/* Action Controls */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              aria-label="Search city"
              className="min-h-[44px] px-3 sm:px-4 flex items-center gap-2 rounded-xl bg-slate-900/5 dark:bg-white/10 hover:bg-slate-900/10 dark:hover:bg-white/15 text-slate-800 dark:text-slate-100 text-sm font-medium transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
            >
              <Search className="h-4 w-4 shrink-0" />
              <span className="hidden sm:inline">Search City</span>
            </button>

            <button
              type="button"
              onClick={() => void detectAndLoadCurrentLocation(false)}
              disabled={locatingGps}
              aria-label="Use current location"
              title="Use current device location"
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-slate-900/5 dark:bg-white/10 hover:bg-slate-900/10 dark:hover:bg-white/15 text-slate-800 dark:text-slate-100 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
            >
              {locatingGps ? (
                <Loader2 className="h-4 w-4 animate-spin text-sky-500" />
              ) : (
                <Navigation className="h-4 w-4" />
              )}
            </button>

            <button
              type="button"
              onClick={handleRefresh}
              disabled={refreshing || loading}
              aria-label="Refresh weather"
              title="Refresh live weather"
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-slate-900/5 dark:bg-white/10 hover:bg-slate-900/10 dark:hover:bg-white/15 text-slate-800 dark:text-slate-100 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
            >
              <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin text-sky-500' : ''}`} />
            </button>

            <button
              type="button"
              onClick={() => setUnit((u) => (u === 'C' ? 'F' : 'C'))}
              aria-label={`Switch temperature unit to ${unit === 'C' ? 'Fahrenheit' : 'Celsius'}`}
              className="min-h-[44px] min-w-[44px] px-2.5 flex items-center justify-center rounded-xl bg-slate-900/5 dark:bg-white/10 hover:bg-slate-900/10 dark:hover:bg-white/15 font-display text-sm font-semibold text-slate-800 dark:text-slate-100 transition-colors tabular-nums focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
            >
              °{unit}
            </button>

            <button
              type="button"
              onClick={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
              aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`}
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-slate-900/5 dark:bg-white/10 hover:bg-slate-900/10 dark:hover:bg-white/15 text-slate-800 dark:text-slate-100 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-500"
            >
              {theme === 'dark' ? <Sun className="h-4 w-4 text-amber-300" /> : <Moon className="h-4 w-4 text-slate-700" />}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="mx-auto max-w-6xl px-4 sm:px-6 pt-5 pb-12 pb-safe">
        {/* Location Permission / Fallback Banner */}
        {locationNotice && (
          <div className="mb-4 flex items-center justify-between gap-3 rounded-2xl bg-amber-500/10 dark:bg-amber-400/10 border border-amber-500/25 px-4 py-3 text-xs sm:text-sm text-amber-900 dark:text-amber-200">
            <span>{locationNotice}</span>
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              className="min-h-[36px] px-3 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 font-medium whitespace-nowrap shrink-0 transition-colors"
            >
              Change City
            </button>
          </div>
        )}

        {/* Loading State (Initial) */}
        {loading && !weather && (
          <div className="flex flex-col items-center justify-center py-28 text-center">
            <Loader2 className="h-9 w-9 animate-spin text-sky-500 mb-4" />
            <p className="font-display text-lg font-medium text-slate-800 dark:text-slate-200">
              Fetching live atmospheric telemetry...
            </p>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Connecting to Open-Meteo weather network
            </p>
          </div>
        )}

        {/* API Error State (when no weather loaded) */}
        {errorMsg && !weather && !loading && (
          <div className="mx-auto max-w-md my-16 rounded-3xl bg-white/80 dark:bg-slate-900/75 backdrop-blur-xl border border-rose-500/25 p-6 text-center shadow-sm">
            <AlertCircle className="mx-auto h-10 w-10 text-rose-500 mb-3" />
            <h2 className="font-display text-lg font-semibold text-slate-900 dark:text-white">
              Weather Data Unavailable
            </h2>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">{errorMsg}</p>
            <div className="mt-5 flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={handleRefresh}
                className="min-h-[44px] px-5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-sm font-medium transition-colors"
              >
                Retry
              </button>
              <button
                type="button"
                onClick={() => setSearchOpen(true)}
                className="min-h-[44px] px-5 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-900 dark:text-white text-sm font-medium transition-colors"
              >
                Search City
              </button>
            </div>
          </div>
        )}

        {/* Error Toast if refresh failed while existing data is visible */}
        {errorMsg && weather && (
          <div className="mb-4 flex items-center justify-between gap-3 rounded-2xl bg-rose-500/10 border border-rose-500/25 px-4 py-3 text-xs sm:text-sm text-rose-700 dark:text-rose-300">
            <span className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 shrink-0" />
              {errorMsg}
            </span>
            <button
              type="button"
              onClick={handleRefresh}
              className="min-h-[36px] px-3 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 font-medium shrink-0"
            >
              Retry
            </button>
          </div>
        )}

        {/* Active Live Weather Dashboard */}
        {weather && (
          <div className="space-y-5">
            {/* Hero Current Weather Section */}
            <section
              aria-label="Current weather overview"
              className="rounded-3xl bg-white/75 dark:bg-slate-900/65 backdrop-blur-xl border border-slate-200/80 dark:border-white/10 p-6 sm:p-8 shadow-sm"
            >
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
                {/* Left: Location, Date/Time, Hero Temp */}
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200">
                      <MapPin className="h-4 w-4 text-sky-500 shrink-0" />
                      <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
                        {weather.location.name}
                        {weather.location.country ? `, ${weather.location.country}` : ''}
                      </h1>
                    </div>
                    <p className="mt-1.5 text-sm text-slate-500 dark:text-slate-400 tabular-nums">
                      {cityClock.dateText}
                      <span className="mx-2" aria-hidden="true">·</span>
                      Local time {cityClock.timeText}
                      {weather.location.isCurrentLocation && (
                        <>
                          <span className="mx-2" aria-hidden="true">·</span>
                          <span>Device GPS</span>
                        </>
                      )}
                    </p>
                  </div>

                  <div className="flex items-end gap-5 pt-1">
                    <div className="font-display text-7xl sm:text-8xl font-bold tracking-tighter leading-none text-slate-900 dark:text-white tabular-nums">
                      {formatTemperature(weather.current.temperature, unit)}°
                    </div>

                    <div className="pb-1.5 space-y-1">
                      <p className="font-display text-xl sm:text-2xl font-semibold text-slate-800 dark:text-slate-100">
                        {currentInfo.label}
                      </p>
                      <p className="text-sm text-slate-600 dark:text-slate-300 tabular-nums">
                        Feels like {formatTemperature(weather.current.apparentTemperature, unit)}°{unit}
                        {todayForecast && (
                          <>
                            <span className="mx-2" aria-hidden="true">·</span>
                            H: {formatTemperature(todayForecast.tempMax, unit)}°
                            <span className="mx-1.5" aria-hidden="true">/</span>
                            L: {formatTemperature(todayForecast.tempMin, unit)}°
                          </>
                        )}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Right: Hero Weather Visual + Updated Timestamp */}
                <div className="flex md:flex-col items-center md:items-end justify-between gap-4">
                  <div className="flex h-28 w-28 sm:h-32 sm:w-32 items-center justify-center rounded-3xl bg-gradient-to-br from-sky-500/15 to-indigo-500/15 dark:from-sky-400/15 dark:to-indigo-500/20">
                    <WeatherIcon
                      code={weather.current.weatherCode}
                      isDay={weather.current.isDay}
                      size="hero"
                    />
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 tabular-nums text-right">
                    Updated {lastUpdatedLabel}
                  </p>
                </div>
              </div>
            </section>

            {/* 2-Column Responsive Dashboard Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
              {/* Left Primary Column: Hourly + Atmospheric Metrics */}
              <div className="lg:col-span-7 space-y-5">
                <HourlyForecastCard hourly={weather.hourly} unit={unit} />
                <WeatherMetricsGrid
                  current={weather.current}
                  today={todayForecast}
                  unit={unit}
                />
              </div>

              {/* Right Column: 7-Day Forecast */}
              <div className="lg:col-span-5 space-y-5">
                <DailyForecastCard daily={weather.daily} unit={unit} />

                {/* Recent Locations Quick Switcher (if multiple saved) */}
                {recentLocations.length > 1 && (
                  <section
                    aria-label="Recent cities"
                    className="rounded-3xl bg-white/75 dark:bg-slate-900/65 backdrop-blur-xl border border-slate-200/80 dark:border-white/10 p-5 shadow-sm"
                  >
                    <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white mb-3">
                      Quick Switch
                    </h2>
                    <div className="flex flex-wrap gap-2">
                      {recentLocations.map((loc) => {
                        const isSelected =
                          Math.abs(loc.latitude - weather.location.latitude) < 0.02 &&
                          Math.abs(loc.longitude - weather.location.longitude) < 0.02;
                        return (
                          <button
                            key={loc.id}
                            type="button"
                            onClick={() => handleSelectCity(loc)}
                            className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-medium transition-colors whitespace-nowrap ${
                              isSelected
                                ? 'bg-sky-600 text-white'
                                : 'bg-slate-100 dark:bg-white/10 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-white/15'
                            }`}
                          >
                            {loc.name}
                          </button>
                        );
                      })}
                    </div>
                  </section>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Quiet Footer */}
        <footer className="mt-10 pt-5 border-t border-slate-300/50 dark:border-white/10 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
          <span>ZEE WEATHER · Created By Zain</span>
          <span>Live meteorological data by Open-Meteo</span>
        </footer>
      </main>

      <CitySearchModal
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        onSelectLocation={handleSelectCity}
        onUseCurrentLocation={() => void detectAndLoadCurrentLocation(false)}
        locatingGps={locatingGps}
        recentLocations={recentLocations}
      />
    </div>
  );
}
