import type { TemperatureUnit, WeatherCategory } from '../types/weather';

export interface WeatherCodeInfo {
  label: string;
  shortLabel: string;
  category: WeatherCategory;
}

const WMO_CODE_MAP: Record<number, WeatherCodeInfo> = {
  0: { label: 'Clear Sky', shortLabel: 'Clear', category: 'clear' },
  1: { label: 'Mainly Clear', shortLabel: 'Mostly Clear', category: 'clear' },
  2: { label: 'Partly Cloudy', shortLabel: 'Partly Cloudy', category: 'partly-cloudy' },
  3: { label: 'Overcast', shortLabel: 'Overcast', category: 'cloudy' },
  45: { label: 'Fog', shortLabel: 'Fog', category: 'fog' },
  48: { label: 'Depositing Rime Fog', shortLabel: 'Rime Fog', category: 'fog' },
  51: { label: 'Light Drizzle', shortLabel: 'Drizzle', category: 'drizzle' },
  53: { label: 'Moderate Drizzle', shortLabel: 'Drizzle', category: 'drizzle' },
  55: { label: 'Dense Drizzle', shortLabel: 'Heavy Drizzle', category: 'drizzle' },
  56: { label: 'Freezing Drizzle', shortLabel: 'Freezing Drizzle', category: 'drizzle' },
  57: { label: 'Dense Freezing Drizzle', shortLabel: 'Freezing Drizzle', category: 'drizzle' },
  61: { label: 'Slight Rain', shortLabel: 'Light Rain', category: 'rain' },
  63: { label: 'Moderate Rain', shortLabel: 'Rain', category: 'rain' },
  65: { label: 'Heavy Rain', shortLabel: 'Heavy Rain', category: 'rain' },
  66: { label: 'Light Freezing Rain', shortLabel: 'Freezing Rain', category: 'rain' },
  67: { label: 'Heavy Freezing Rain', shortLabel: 'Freezing Rain', category: 'rain' },
  71: { label: 'Slight Snowfall', shortLabel: 'Light Snow', category: 'snow' },
  73: { label: 'Moderate Snowfall', shortLabel: 'Snow', category: 'snow' },
  75: { label: 'Heavy Snowfall', shortLabel: 'Heavy Snow', category: 'snow' },
  77: { label: 'Snow Grains', shortLabel: 'Snow Grains', category: 'snow' },
  80: { label: 'Slight Rain Showers', shortLabel: 'Showers', category: 'rain' },
  81: { label: 'Moderate Rain Showers', shortLabel: 'Rain Showers', category: 'rain' },
  82: { label: 'Violent Rain Showers', shortLabel: 'Heavy Showers', category: 'rain' },
  85: { label: 'Slight Snow Showers', shortLabel: 'Snow Showers', category: 'snow' },
  86: { label: 'Heavy Snow Showers', shortLabel: 'Heavy Snow', category: 'snow' },
  95: { label: 'Thunderstorm', shortLabel: 'Thunderstorm', category: 'thunderstorm' },
  96: { label: 'Thunderstorm with Slight Hail', shortLabel: 'Storm & Hail', category: 'thunderstorm' },
  99: { label: 'Thunderstorm with Heavy Hail', shortLabel: 'Severe Storm', category: 'thunderstorm' },
};

export function getWeatherInfo(code: number): WeatherCodeInfo {
  return (
    WMO_CODE_MAP[code] ?? {
      label: 'Variable Conditions',
      shortLabel: 'Variable',
      category: 'partly-cloudy',
    }
  );
}

export function formatTemperature(celsius: number, unit: TemperatureUnit): number {
  if (unit === 'F') {
    return Math.round((celsius * 9) / 5 + 32);
  }
  return Math.round(celsius);
}

export function formatWindSpeed(kmh: number, unit: TemperatureUnit): string {
  if (unit === 'F') {
    return `${Math.round(kmh * 0.621371)} mph`;
  }
  return `${Math.round(kmh)} km/h`;
}

export function formatVisibility(meters: number, unit: TemperatureUnit): string {
  if (unit === 'F') {
    const miles = meters / 1609.34;
    return `${miles >= 10 ? Math.round(miles) : miles.toFixed(1)} mi`;
  }
  const km = meters / 1000;
  return `${km >= 10 ? Math.round(km) : km.toFixed(1)} km`;
}

export function getWindCompass(degrees: number): string {
  const dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  const index = Math.round((((degrees % 360) + 360) % 360) / 45) % 8;
  return dirs[index];
}

export function getUvRating(uv: number): { label: string; tone: 'low' | 'moderate' | 'high' | 'extreme' } {
  if (uv < 3) return { label: 'Low', tone: 'low' };
  if (uv < 6) return { label: 'Moderate', tone: 'moderate' };
  if (uv < 8) return { label: 'High', tone: 'high' };
  if (uv < 11) return { label: 'Very High', tone: 'extreme' };
  return { label: 'Extreme', tone: 'extreme' };
}

export function getPressureLabel(hpa: number): string {
  if (hpa < 1005) return 'Low Pressure';
  if (hpa > 1020) return 'High Pressure';
  return 'Normal';
}

export function formatCityDateTime(timezone: string, now: Date = new Date()): {
  dateText: string;
  timeText: string;
} {
  try {
    const dateText = new Intl.DateTimeFormat('en-US', {
      timeZone: timezone,
      weekday: 'long',
      month: 'short',
      day: 'numeric',
    }).format(now);

    const timeText = new Intl.DateTimeFormat('en-US', {
      timeZone: timezone,
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    }).format(now);

    return { dateText, timeText };
  } catch {
    return {
      dateText: now.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' }),
      timeText: now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true }),
    };
  }
}

export function formatIsoHour(isoString: string): string {
  // Open-Meteo returns local ISO strings like "2026-11-23T14:00"
  const timePart = isoString.split('T')[1];
  if (!timePart) return isoString;
  const hour = Number.parseInt(timePart.split(':')[0] ?? '0', 10);
  if (Number.isNaN(hour)) return isoString;
  const period = hour >= 12 ? 'PM' : 'AM';
  const displayHour = hour % 12 === 0 ? 12 : hour % 12;
  return `${displayHour} ${period}`;
}

export function formatIsoTimeExact(isoString: string): string {
  const timePart = isoString.split('T')[1];
  if (!timePart) return isoString;
  const [hStr, mStr] = timePart.split(':');
  const hour = Number.parseInt(hStr ?? '0', 10);
  const minute = mStr ?? '00';
  if (Number.isNaN(hour)) return isoString;
  const period = hour >= 12 ? 'PM' : 'AM';
  const displayHour = hour % 12 === 0 ? 12 : hour % 12;
  return `${displayHour}:${minute} ${period}`;
}

export function formatIsoDayName(dateString: string, index: number): string {
  if (index === 0) return 'Today';
  const [y, m, d] = dateString.split('-').map(Number);
  if (!y || !m || !d) return dateString;
  const dateObj = new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
  return new Intl.DateTimeFormat('en-US', { weekday: 'short', timeZone: 'UTC' }).format(dateObj);
}

export function formatIsoShortDate(dateString: string): string {
  const [y, m, d] = dateString.split('-').map(Number);
  if (!y || !m || !d) return dateString;
  const dateObj = new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
  return new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' }).format(dateObj);
}

export function getSolarProgress(sunriseIso: string, sunsetIso: string, currentIso: string): number {
  const parseMinutes = (iso: string) => {
    const t = iso.split('T')[1];
    if (!t) return 0;
    const [h, m] = t.split(':').map(Number);
    return (h || 0) * 60 + (m || 0);
  };
  const rise = parseMinutes(sunriseIso);
  const set = parseMinutes(sunsetIso);
  const cur = parseMinutes(currentIso);
  if (set <= rise) return 0.5;
  if (cur <= rise) return 0;
  if (cur >= set) return 1;
  return (cur - rise) / (set - rise);
}
